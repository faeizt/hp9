<?
$date = date("Y-m-d");
?>
<input type="hidden" id="project_list" value="MARA01,LHDN02">
<input type="hidden" id="today" value="<?=$date?>">

<?
include ("nav/header.php");
?>

      <div id="page-wrapper" class="panel-body">
        <div class="row">
          <div class="col-lg-12">
            <div class="page-title">
              <h1>Dashboard <small>Content Overview</small></h1>
              <ol class="breadcrumb">
                <li class="active"><i class="fa fa-dashboard"></i> Dashboard</li>
                <li class="pull-right" style="margin-top: 0px;">
                  <div id="reportrange" class="btn btn-success pull-right date-picker">
                      <i class="fa fa-calendar fa-lg"></i>
                      <span><?php echo date("F j, Y"); ?></span> <b class="caret"></b>
                  </div>

<!--                   <div id="btn-reportrange" class="btn btn-success btn-square date-picker">
                    <i class="fa fa-calendar"></i>
                    <span class="date-range">December 10, 2013 - January 8, 2014</span> <i class="fa fa-caret-down"></i>
                  </div> -->
<!--                   <div id="div_reportrange" class="pop-dialog" style="display:none">
                    <div class="pointer">
                        <div class="arrow"></div>
                        <div class="arrow_border"></div>
                    </div>
                    <div class="body">
                        <div class="menu">
                            <a href="#" class="item btn btn-success btn-xs">Today</a>
                            <a href="#" class="item btn btn-success btn-xs">Yesterday</a>
                            <a href="#" class="item btn btn-success btn-xs">Last 7 Days</a>
                            <a href="#" class="item btn btn-success btn-xs">Last 30 Days</a>
                            <a href="#" class="item btn btn-success btn-xs">This Month</a>
                            <a href="#" class="item btn btn-success btn-xs">Last Month</a>
                            <a href="#" class="item btn btn-success btn-xs">Custom Range</a>
                            <input type="text" style="width:47%" > - <input type="text" style="width:48%">
                        </div>
                        <div class="footer" >
                            <button type="button" class="btn btn-primary">Submit</button> <button type="button" class="btn btn-default">Cancel</button>
                        </div>
                    </div>
                </div>  -->                    
                </li>
              </ol>
     
            </div>
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-3">
            <div class="panel panel-info">
              <div class="panel-heading">
                <div class="row">
                  <div class="col-xs-2">
                    <i class="fa fa-tint fa-5x"></i>
                  </div>
                  <div class="col-xs-10 text-right"><p class="announcement-heading" id="onsite">0</p></div>
                  <div class="col-xs-12 text-right"><p class="announcement-text">Engineer Onsite Incidents</p></div>

                </div>
              </div>
              <a href="#">
                <div class="panel-footer announcement-bottom">
                  <div class="row">
                    <div class="col-xs-6">
                      View Incident
                    </div>
                    <div class="col-xs-6 text-right">
                      <i class="fa fa-arrow-circle-right"></i>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="panel panel-warning">
              <div class="panel-heading">
                <div class="row">
                  <div class="col-xs-2">
                    <i class="fa fa-fire fa-5x"></i>
                  </div>
                  <div class="col-xs-10 text-right"><p class="announcement-heading" id="open">0</p></div>
                  <div class="col-xs-12 text-right"><p class="announcement-text">New Incidents</p></div>
                </div>
              </div>
              <a href="#">
                <div class="panel-footer announcement-bottom">
                  <div class="row">
                    <div class="col-xs-10">
                      View Incidents
                    </div>
                    <div class="col-xs-2 text-right">
                      <i class="fa fa-arrow-circle-right"></i>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="panel panel-danger">
              <div class="panel-heading">
                <div class="row">
                  <div class="col-xs-2">
                    <i class="fa fa-minus-circle fa-5x"></i>
                  </div>
                  <div class="col-xs-10 text-right"><p class="announcement-heading" id="pending">0</p></div>
                  <div class="col-xs-12 text-right"><p class="announcement-text">Pending Incidents</p></div>
                </div>
              </div>
              <a href="#">
                <div class="panel-footer announcement-bottom">
                  <div class="row">
                    <div class="col-xs-10">
                      View Incidents
                    </div>
                    <div class="col-xs-2 text-right">
                      <i class="fa fa-arrow-circle-right"></i>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="panel panel-success">
              <div class="panel-heading">
                <div class="row">
                  <div class="col-xs-2">
                    <i class="fa fa-check fa-5x"></i>
                  </div>
                  <div class="col-xs-10 text-right"><p class="announcement-heading" id="resolve">0</p></div>
                  <div class="col-xs-12 text-right"><p class="announcement-text">Resolved Incidents</p></div>

                </div>
              </div>
              <a href="#">
                <div class="panel-footer announcement-bottom">
                  <div class="row">
                    <div class="col-xs-10">
                      View Incidents
                    </div>
                    <div class="col-xs-2 text-right">
                      <i class="fa fa-arrow-circle-right"></i>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-12">

              <div class="panel-body">
              <style type="text/css">
                #statsChart {
                height: 300px;
                margin-top: 35px;
                margin-bottom:   50px;
                }
              </style>
            <!-- statistics chart built with jQuery Flot -->
            <div class="row chart">
                <div class="col-md-12">
                    <h4 class="clearfix pull-left">
                        Statistics                         
                    </h4>
<!--                     <div class="btn-group pull-right">
                        <button class="glow left">DAY</button>
                        <button class="glow middle active">MONTH</button>
                        <button class="glow right">YEAR</button>
                    </div> -->
                </div>
                <div class="col-md-12">
                    <div id="statsChart"></div>
                </div>
            </div>
            <!-- end statistics chart -->
            </div>
          </div>
        </div><!-- /.row -->

<!--         <div class="row">
          <div class="col-lg-4">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-long-arrow-right"></i> Traffic Sources: October 1, 2013 - October 31, 2013</h3>
              </div>
              <div class="panel-body">
                <div id="morris-chart-donut"></div>
                <div class="text-right">
                  <a href="#">View Details <i class="fa fa-arrow-circle-right"></i></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-clock-o"></i> Recent Activity</h3>
              </div>
              <div class="panel-body">
                <div class="list-group">
                  <a href="#" class="list-group-item">
                    <span class="badge">just now</span>
                    <i class="fa fa-calendar"></i> Calendar updated
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="badge">4 minutes ago</span>
                    <i class="fa fa-comment"></i> Commented on a post
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="badge">23 minutes ago</span>
                    <i class="fa fa-truck"></i> Order 392 shipped
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="badge">46 minutes ago</span>
                    <i class="fa fa-money"></i> Invoice 653 has been paid
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="badge">1 hour ago</span>
                    <i class="fa fa-user"></i> A new user has been added
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="badge">2 hours ago</span>
                    <i class="fa fa-check"></i> Completed task: "pick up dry cleaning"
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="badge">yesterday</span>
                    <i class="fa fa-globe"></i> Saved the world
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="badge">two days ago</span>
                    <i class="fa fa-check"></i> Completed task: "fix error on sales page"
                  </a>
                </div>
                <div class="text-right">
                  <a href="#">View All Activity <i class="fa fa-arrow-circle-right"></i></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-money"></i> Recent Transactions</h3>
              </div>
              <div class="panel-body">
                <div class="table-responsive">
                  <table class="table table-bordered table-hover table-striped tablesorter">
                    <thead>
                      <tr>
                        <th>Order # <i class="fa fa-sort"></i></th>
                        <th>Order Date <i class="fa fa-sort"></i></th>
                        <th>Order Time <i class="fa fa-sort"></i></th>
                        <th>Amount (USD) <i class="fa fa-sort"></i></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>3326</td>
                        <td>10/21/2013</td>
                        <td>3:29 PM</td>
                        <td>$321.33</td>
                      </tr>
                      <tr>
                        <td>3325</td>
                        <td>10/21/2013</td>
                        <td>3:20 PM</td>
                        <td>$234.34</td>
                      </tr>
                      <tr>
                        <td>3324</td>
                        <td>10/21/2013</td>
                        <td>3:03 PM</td>
                        <td>$724.17</td>
                      </tr>
                      <tr>
                        <td>3323</td>
                        <td>10/21/2013</td>
                        <td>3:00 PM</td>
                        <td>$23.71</td>
                      </tr>
                      <tr>
                        <td>3322</td>
                        <td>10/21/2013</td>
                        <td>2:49 PM</td>
                        <td>$8345.23</td>
                      </tr>
                      <tr>
                        <td>3321</td>
                        <td>10/21/2013</td>
                        <td>2:23 PM</td>
                        <td>$245.12</td>
                      </tr>
                      <tr>
                        <td>3320</td>
                        <td>10/21/2013</td>
                        <td>2:15 PM</td>
                        <td>$5663.54</td>
                      </tr>
                      <tr>
                        <td>3319</td>
                        <td>10/21/2013</td>
                        <td>2:13 PM</td>
                        <td>$943.45</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div class="text-right">
                  <a href="#">View All Transactions <i class="fa fa-arrow-circle-right"></i></a>
                </div>
              </div>
            </div>
          </div>
        </div> --><!-- /.row -->
      </div><!-- /#page-wrapper -->
    <script src="js/jquery.flot.js"></script>
    <script src="js/jquery.flot.stack.js"></script>
    <script src="js/jquery.flot.resize.js"></script>      
<script type="text/javascript">
$(function () {
            $.getJSON("../lookup/widget_json.php?begin="+ $('#today').val()+"&end="+$('#today').val(), function(json) {
                $('#open').html(json[0].open_date);
                $('#onsite').html(json[1].onsite_time);
                $('#pending').html(json[2].pending_time);
                $('#resolve').html(json[3].resolve_time);

          })

})
$('#reportrange').daterangepicker(
    {
      ranges: {
         'Today': [moment(), moment()],
         'Yesterday': [moment().subtract('days', 1), moment().subtract('days', 1)],
         'Last 7 Days': [moment().subtract('days', 6), moment()],
         'Last 30 Days': [moment().subtract('days', 29), moment()],
         'This Month': [moment().startOf('month'), moment().endOf('month')],
         'Last Month': [moment().subtract('month', 1).startOf('month'), moment().subtract('month', 1).endOf('month')]
      },
      startDate: moment(),
      endDate: moment()
    },
    function(start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
        // alert("Callback has fired: [" + start.format('YYYY-MM-D') + " to " + end.format('YYYY-MM-D') + "]");
        var begin = start.format('YYYY-MM-D');
        var end = end.format('YYYY-MM-D');
          $.getJSON("lookup/widget_json.php?begin="+ begin+"&end="+end, function(json) {
                $('#open').html(json[0].open_date);
                $('#onsite').html(json[1].onsite_time);
                $('#pending').html(json[2].pending_time);
                $('#resolve').html(json[3].resolve_time);

          })

    }
);





</script>
<script type="text/javascript">
          $(function () {


            // jQuery Flot Chart
            // var visits = [[1, 50], [2, 40], [3, 45], [4, 23],[5, 55],[6, 65],[7, 61],[8, 70],[9, 65],[10, 75],[11, 57],[12, 59]];
            // var visitors = [[1, 298], [2, 50], [3, 23], [4, 48],[5, 38],[6, 40],[7, 47],[8, 55],[9, 43],[10,50],[11,47],[12, 39]];
            var data = [];
var currnt_image_list = $('#project_list').val();
$.each(currnt_image_list.split(','), function(index, value) { 
  $.getJSON("lookup/graph_json5.php?project="+value, function(json) {
                data.push(json);
 var plotarea = $("#statsChart");
            $.plot(plotarea , data,
           {
                              series: {
                                  lines: { show: true,
                                          lineWidth: 1,
                                          fill: true, 
                                          fillColor: { colors: [ { opacity: 0.1 }, { opacity: 0.13 } ] }
                                       },
                                  points: { show: true, 
                                           lineWidth: 2,
                                           radius: 3
                                       },
                                  shadowSize: 0,
                                  stack: true
                              },
                              grid: { hoverable: true, 
                                     clickable: true, 
                                     tickColor: "#f9f9f9",
                                     borderWidth: 0
                                  },
                              legend: {
                                      // show: false
                                      labelBoxBorderColor: "#fff"
                                  },  
                              colors: ["#a7b5c5", "#30a0eb"],
                              xaxis: {
                                  ticks: [[1, "JAN"], [2, "FEB"], [3, "MAR"], [4,"APR"], [5,"MAY"], [6,"JUN"], [7,"JUL"], [8,"AUG"], [9,"SEP"], [10,"OCT"], [11,"NOV"], [12,"DEC"]],
                                  font: {
                                      size: 12,
                                      family: "Open Sans, Arial",
                                      variant: "small-caps",
                                      color: "#697695"
                                  }
                              },
                              yaxis: {
                                  ticks:3, 
                                  tickDecimals: 0,
                                  font: {size:12, color: "#9da3a9"}
                              }
                           }            
        );
  });
});
// $.getJSON("lookup/graph_json3.php", function(json) {
//        //succes - data loaded, now use plot:
//            var plotarea = $("#statsChart");
//            var dataBar=json.dataBar;
//             var dataLine=json.dataLine;
//             data.push(json);

//     });
            // var plot = $.plot($("#statsChart"),[ { data: visits, label: "Signups"}, { data: visitors, label: "Visits" }], {
            //         series: {
            //             lines: { show: true,
            //                     lineWidth: 1,
            //                     fill: true, 
            //                     fillColor: { colors: [ { opacity: 0.1 }, { opacity: 0.13 } ] }
            //                  },
            //             points: { show: true, 
            //                      lineWidth: 2,
            //                      radius: 3
            //                  },
            //             shadowSize: 0,
            //             stack: true
            //         },
            //         grid: { hoverable: true, 
            //                clickable: true, 
            //                tickColor: "#f9f9f9",
            //                borderWidth: 0
            //             },
            //         legend: {
            //                 // show: false
            //                 labelBoxBorderColor: "#fff"
            //             },  
            //         colors: ["#a7b5c5", "#30a0eb"],
            //         xaxis: {
            //             ticks: [[1, "JAN"], [2, "FEB"], [3, "MAR"], [4,"APR"], [5,"MAY"], [6,"JUN"], [7,"JUL"], [8,"AUG"], [9,"SEP"], [10,"OCT"], [11,"NOV"], [12,"DEC"]],
            //             font: {
            //                 size: 12,
            //                 family: "Open Sans, Arial",
            //                 variant: "small-caps",
            //                 color: "#697695"
            //             }
            //         },
            //         yaxis: {
            //             ticks:3, 
            //             tickDecimals: 0,
            //             font: {size:12, color: "#9da3a9"}
            //         }
            //      });

            function showTooltip(x, y, contents) {
                $('<div id="tooltip">' + contents + '</div>').css( {
                    position: 'absolute',
                    display: 'none',
                    top: y - 30,
                    left: x - 50,
                    color: "#fff",
                    padding: '2px 5px',
                    'border-radius': '6px',
                    'background-color': '#000',
                    opacity: 0.80
                }).appendTo("body").fadeIn(200);
            }

            var previousPoint = null;
            $("#statsChart").bind("plothover", function (event, pos, item) {
                if (item) {
                    if (previousPoint != item.dataIndex) {
                        previousPoint = item.dataIndex;

                        $("#tooltip").remove();
                        var x = item.datapoint[0].toFixed(0),
                            y = item.datapoint[1].toFixed(0);

                        var month = item.series.xaxis.ticks[item.dataIndex].label;

                        showTooltip(item.pageX, item.pageY,
                                    item.series.label + " of " + month + ": " + y);
                    }
                }
                else {
                    $("#tooltip").remove();
                    previousPoint = null;
                }
            });
        });
</script>

<?
include ("nav/footer.php");
?>

