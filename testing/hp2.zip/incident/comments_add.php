<?
session_start();
if(isset($_POST['case_id'])){
	include '../DB.php';
	$case_id  	= mysql_real_escape_string(htmlspecialchars(trim($_POST['case_id'])));
	$comments	= mysql_real_escape_string(htmlspecialchars(trim($_POST['comments'])));
	$user_id	= $_SESSION['user_id'];

	$addApplication			= 	"INSERT INTO comments (case_id, user_id,comments,date) VALUES ('$case_id','$user_id','$comments',now())";

	if(mysql_query($addApplication)){
		echo "true";
	}else{echo "app=".$addApplication;}        								
}
else{   echo "false";}//return auth value
?>