<?php 
 session_start();
   if (isset($_SESSION['username'])){
     include '../../DB.php';
   if(isset($_POST['case_id'])){
      $case_id				= htmlspecialchars(trim($_POST['case_id']));
      $user_id		   = htmlspecialchars(trim($_POST['engineer']));
      $engineer_name       = htmlspecialchars(trim($_POST['engineer_name']));
      $assign_note	= htmlspecialchars(trim($_POST['note']));
      $assign_by     = $_SESSION['username'];


      $addAssignment = "INSERT INTO assignment (case_id,user_id,assign_by, assign_date,assign_note) VALUES ('".$case_id."','".$user_id."','$assign_by',now(),'".$assign_note."')";
       if(mysql_query($addAssignment)){
          $updateCase = "update cases set sts = '1',engineer = '$user_id' where case_id='$case_id'";
          mysql_query($updateCase);
           //this will be displayed when the query was successful
           echo "true";
       }else{
           die("SQL: ".$addAssignment." >> ".mysql_error());
       }
   }
}?>