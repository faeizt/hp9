<?session_start();
if (!isset($_SESSION['username'])){
      header( 'Location: ../index.html' ) ;
}
if(isset($_POST['case_id'])){
	include '../../DB.php';
	$case_id  			= mysql_real_escape_string(htmlspecialchars(trim($_POST['case_id'])));
	$site    			= mysql_real_escape_string(htmlspecialchars(trim($_POST['site'])));
	$address			= mysql_real_escape_string(htmlspecialchars(trim($_POST['address'])));
	$report_channel		= mysql_real_escape_string(htmlspecialchars(trim($_POST['report_channel'])));
	$contact_person		= mysql_real_escape_string(htmlspecialchars(trim($_POST['contact_person'])));
	$contact_no			= mysql_real_escape_string(htmlspecialchars(trim($_POST['contact_no'])));
	$add_info			= mysql_real_escape_string(htmlspecialchars(trim($_POST['add_info'])));
	$title 				= mysql_real_escape_string(htmlspecialchars(trim($_POST['title'])));
	$description		= mysql_real_escape_string(htmlspecialchars(trim($_POST['description'])));
	$sn					= mysql_real_escape_string(htmlspecialchars(trim($_POST['sn'])));
	$asset				= mysql_real_escape_string(htmlspecialchars(trim($_POST['asset'])));
	$service_type		= mysql_real_escape_string(htmlspecialchars(trim($_POST['service_type'])));
	$category			= mysql_real_escape_string(htmlspecialchars(trim($_POST['category'])));
	$sla	 			= mysql_real_escape_string(htmlspecialchars(trim($_POST['sla'])));
	$severity 			= mysql_real_escape_string(htmlspecialchars(trim($_POST['severity'])));
	$recurrence 		= mysql_real_escape_string(htmlspecialchars(trim($_POST['recurrence'])));

   $addCase  = "update CASES set ".
   	"site_id = '".$site."', ".
   	"addr_id ='".$address."',  ".
   	"caller = '".$contact_person."', ".
   	"contact = '".$contact_no."', ".
   	"info = '".$add_info."', ".
   	"via = '".$report_channel."', ". 
   	"servType = '".$service_type."', ".
   	"cat = '".$category."', ".
   	"asset = UCASE('".$asset."'), ".
   	"sn = UCASE('".$sn."'), ".
   	"title = '".$title."', ".
   	"problem = '".$description."', ".
   	"flag = '".$severity."', ".
   	"recurrence = '".$recurrence."' ".
   	"where case_id = '$case_id'";
    mysql_query($addCase) or die($addCase .mysql_error());
    echo"SAVED";
}
?>