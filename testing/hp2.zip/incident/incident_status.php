          <style type="text/css">
                .bs-glyphicons {
                padding-left: 0;
                padding-bottom: 1px;
                margin-bottom: 20px;
                list-style: none;
                overflow: hidden;
                }
                #seven .label{ display:block; }
                #four .bs-glyphicons li,#seven .bs-glyphicons li {
                float: left;
                width: 25%;
                min-height: 150px;
                padding: 10px;
                margin: 0 -1px -1px 0;
                font-size: 14px;
                line-height: 1.4;
                text-align: center;
                border: 1px solid #ddd;}  
                #five .bs-glyphicons li {
                float: left;
/*                width: 25%;
*/                min-height: 350px;
                padding: 10px;
                margin: 0 -1px -1px 0;
                font-size: 12px;
                line-height: 1.4;
                text-align: center;
                border: 1px solid #ddd;}          
                #four li:hover .edit{  display:inline;background-color: #E4F8FF; text-align: center}
                .edit {position: absolute;display: none;top: 1px;right: 1px;}
          </style>
<?
include '../DB.php'; //DB Connection String

if(isset($_GET['case_id'])){
  $case_id    =   htmlspecialchars(trim($_GET['case_id']));
  $sqlquery   =   "SELECT  DATE_FORMAT(close_date,'%d/%m/%Y %H:%i') status_close_date, DATE_FORMAT(open_date,'%d/%m/%Y %H:%i') status_open_date,DATE_FORMAT(onsite_time,'%d/%m/%Y %H:%i') status_onsite_time,DATE_FORMAT(pending_time,'%d/%m/%Y %H:%i') status_pending_time,DATE_FORMAT(resolve_time,'%d/%m/%Y %H:%i') status_resolve_time,`open_date`,`onsite_time`,pending_time,`resolve_time`,`close_date`,`resolution`,sts FROM cases where case_id = '$case_id' ";
  // echo $sqlquery;
  $result     =   mysql_query($sqlquery) or die("sql= ". $sqlquery);          //query
  // $row        =   mysql_fetch_array( $result );
  $num        =   mysql_numrows($result);
  $row        = mysql_fetch_array($result);

if (($row['resolve_time']!="" && $row['resolution']!="" && $row['sts']=="4") ||  ($row['sts']=="5")) {?>
  <div style="clear:both;margin-top:40px;padding:10px;">
    <p><b>Resolution</b></p>  
    <div class="alert alert-success" style="">
    <i class="icon-ok-sign"></i>
      <?=$row['resolution']?>
    </div>                   
    <div class="content"  style="float:right; margin-top:-20px" >
      <span class="label label-success"><i class="icon-time"></i> Resolve Time  </span> &nbsp;<?=$row['status_resolve_time']?>
    </div>
  </div>
<?}
  ?>


  <div id="seven" style="clear:both;margin-top:0px;padding:10px;">

    <p><b>Incident Status</b></p>  
<ul class="bs-glyphicons">
    <?if ($row['open_date']!="") {?>
    <li> 
      <div>
        <p style="font-size:20px"><span class="glyphicon glyphicon-fire"></span></p>
        <p><h3>Open</h3></p>
        
      </div>
      <div style="float:right;margin-top:28px">
        <span class="label label-warning" ><?=$row['status_open_date']?></span>
      </div>
        
    </li>      <?
    }?>   
    <?if ($row['onsite_time']!="" || $row['sts']=="1") {?>   
    <li>
      <div>
      <p style="font-size:20px"><span class="glyphicon glyphicon-tint"></span></p>
      <p><h3>Engineer Onsite</h3></p>    
      </div>
      <div style="float:right;margin-top:0px">
      <span class="label label-info" ><?=$row['status_onsite_time']?></span>
      </div>
    </li>      <?
    }?>        

    <?if ($row['pending_time']!="" || $row['sts']=="3") {?>    
    <li>
      <div>
      <p style="font-size:20px"><span class="glyphicon glyphicon-minus-sign"></span></p>
      <p><h3>Pending</h3></p>    
      </div>
      <div style="float:right;margin-top:28px">
      <span class="label label-danger" ><?=$row['status_pending_time']?></span>
      </div>
    </li><?
    }?>             
    <?if ($row['close_date']!="") {?>
    <li>
      <div>
      <p style="font-size:20px"><span class="glyphicon glyphicon-leaf"></span></p>
      <p><h3>Closed</h3></p>    
      </div>
      <div style="float:right;margin-top:28px">
      <span class="label label-primary"><?=$row['status_close_date']?></span>
      </div>
    </li><?
    }?>     
    </ul>
  </div>        

<?}?>