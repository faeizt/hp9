<?php 
 session_start();
   if (isset($_SESSION['username'])){
     include '../../DB.php';
   if(isset($_POST['case_id'])){
      $status			 = htmlspecialchars(trim($_POST['status']));
      $onsite		   = htmlspecialchars(trim($_POST['onsite']));
      $resolve     = htmlspecialchars(trim($_POST['resolve']));
      $remarks	   = mysql_real_escape_string(htmlspecialchars(trim($_POST['remarks'])));
      $resolution  = mysql_real_escape_string(htmlspecialchars(trim($_POST['resolution'])));
      $mod_by   = $_SESSION['username'];
      $case_id     = $_POST['case_id'];
      if ($resolve =='') {
      $addAssignment = "update cases set sts = '$status',onsite_time=STR_TO_DATE('".$onsite."', '%d/%m/%Y %H:%i'),remarks='$remarks',resolution='$resolution',mod_by='$mod_by',mod_date=now() where case_id= '$case_id'";
      }
      else{
      $addAssignment = "update cases set sts = '$status',onsite_time=STR_TO_DATE('".$onsite."', '%d/%m/%Y %H:%i'),resolve_time=STR_TO_DATE('".$resolve."', '%d/%m/%Y %H:%i'),remarks='$remarks',resolution='$resolution',mod_by='$mod_by',mod_date=now() where case_id= '$case_id'";

      }
      if ($status=='5') {
        $close_time = "update cases set close_date = now() where case_id = '$case_id'";
        mysql_query($close_time);
      }
      if ($status=='3') {
       $pending_time = "update cases set pending_time = now() where case_id = '$case_id'";
       mysql_query($pending_time);
      }
      

       if(mysql_query($addAssignment)){
           //this will be displayed when the query was successful
           
       }else{
        echo "false";
            die("SQL: ".$addAssignment." >> ".mysql_error());
       }
   }
}?>