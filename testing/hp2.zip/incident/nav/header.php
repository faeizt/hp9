<?session_start();
if (!isset($_SESSION['username'])){
      header( 'Location: ../index.html' ) ;
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin</title>

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.css" rel="stylesheet">
    <link href="../css/summernote.css" />
    <!-- Add custom CSS here -->
    <link href="../css/sb-admin.css" rel="stylesheet">
    <link href="../css/dataTables.bootstrap.css" rel="stylesheet">
    <link href="../jquery-ui-1.10.3/css/flick/jquery-ui.css"rel="stylesheet" >    
    <link href="../font-awesome3/css/font-awesome.min.css"rel="stylesheet">
    <link href="../bootstrap3-editable-1.5.1/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet"/>
    <link href="../font-awesome-4.0.3/css/font-awesome.css" rel="stylesheet">
    <!-- Page Specific CSS -->

    <!-- JavaScript -->
    <script src="../js/jquery-1.10.2.min.js"></script>
    <script src="../jquery-ui-1.10.3/js/jquery-ui.js"></script>        
    <script src="../js/bootstrap.js"></script>
    <script src="../js/jquery.dataTables.js"></script>
    <script src="../js/TableTools.js"></script>
    <script src="../js/dataTables.bootstrap.js"></script>
    <script src="../bootstrap3-editable-1.5.1/bootstrap3-editable/js/bootstrap-editable.min.js"></script>   

    <script type="text/javascript">
        (function() {
            var link_element = document.createElement("link"),
                s = document.getElementsByTagName("script")[0];
            if (window.location.protocol !== "http:" && window.location.protocol !== "https:") {
                link_element.href = "http:";
            }
            link_element.href += "//fonts.googleapis.com/css?family=Open+Sans:300italic,300,400italic,400,600italic,600,700italic,700,800italic,800";
            link_element.rel = "stylesheet";
            link_element.type = "text/css";
            s.parentNode.insertBefore(link_element, s);
        })();
    </script>

    <script type="text/javascript">
      function genLoader(t,data,p){
        var term = t;
        var tdata= data;
        var page = 'add-case.php';
        var search="";
        if (p){page = p;}
        if(term=='fltrt1')    {   $("#fltrt1").val(tdata);    }//$('select option[value="MARA01"]').attr("selected",true);;
        else if(term=='fltrt2') {   $("#fltrt2").val(tdata);}
        else if(term=='fltrt3') {   $("#fltrt3").val(tdata);}
        else if(term=='fltrt4') {   $("#fltrt4").val(tdata);}
        else if(term=='fltrt5') {   $("#fltrt5").val(tdata);}
        else if(term=='fltrt6') {   $("#fltrt6").val(tdata);}
        else if(term=='srcht')  {   $("#search").val(tdata); }
        else if(term=='fltr2')  {   $("#fltr2").val(tdata); }
        else if(term=='srt')  {   $("#srt").val(tdata); } 
        else{}
        var loader = page +'?srch=y&srcht='+encodeURIComponent($("#search").val())+'&fltr2='+encodeURIComponent($("#fltr2").val())+'&fltr=y&fltrt1='+$("#fltrt1").val()+'&fltrt2='+$("#fltrt2").val()+'&fltrt3='+$("#fltrt3").val()+'&fltrt4='+$("#fltrt4").val()+'&fltrt5='+$("#fltrt5").val()+'&fltrt6='+$("#fltrt6").val()+'&srt='+encodeURIComponent($("#srt").val());
        return loader
      }

    </script> 
  </head>

  <body  data-spy="scroll" data-offset="0" data-target="#myScrollspy">

    <div id="wrapper" style="">

      <!-- Sidebar -->
      <nav  class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div id="nav-top" class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" ><FONT color="fefefe">THE</FONT> <FONT color="3ca6fb">HELPDESK &nbsp;</FONT></a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-ex1-collapse">
        <style type="text/css">
        .side-nav li i{ font-size: 25px; }
        </style>
          <ul class="nav navbar-nav side-nav">
          <li class="side-user hidden-xs" style="width: 225px;background: brown; color:antiquewhite;text-align: left;padding: 10px;">
              <div class="row">
                <div class="col-md-4"><img class="media-object img-circle" src="../images/uploads/<?=$_SESSION['profile_image']?>" alt="" style="width: 70px;height: 70px;"></div>
                <div class="col-md-8"><br/><i style="font-size:15px" class="fa fa-key"></i> <br/>Logged in as <?=$_SESSION['name']?></div>
              </div>
              <div class="clearfix"></div>

            </li>

            <li><a href=".."><span><i class="fa fa-dashboard"></i></span> <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;DASHBOARD</span></a></li>
            <li class="active"><a href="../incident"><span><i class="fa fa-wrench"></i></span> <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;INCIDENT</span></a></li>
            <li class=""><a href="../report"><span><i class="fa fa-signal"></i></span> <span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;REPORT</span></a></li>
            <li><a href="../inventory"><span><i class="fa fa-dropbox"></i></span> <span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;INVENTORY</span></a></li>
            <li><a href="../config"><span><i class="fa fa-cogs"></i></span> <span> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SETTING</span></a></li>
          </ul>

          <ul class="nav navbar-nav navbar-right navbar-user">

            <li class="dropdown user-dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?=$_SESSION['username']?> <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="../profile?user=<?=$_SESSION['username']?>"><i class="fa fa-user"></i> Profile</a></li>
                <li class="divider"></li>
                <li><a href="../logout.php"><i class="fa fa-power-off"></i> Log Out</a></li>
              </ul>
            </li>
          </ul>

        </div><!-- /.navbar-collapse -->
      </nav>