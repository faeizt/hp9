<?session_start();
if (!isset($_SESSION['username'])){
      header( 'Location: ../index.html' ) ;
}
if(isset($_POST['client'])){
	include '../DB.php';
	$client  			= mysql_real_escape_string(htmlspecialchars(trim($_POST['client'])));
	$project  			= mysql_real_escape_string(htmlspecialchars(trim($_POST['project'])));
	$site    			= mysql_real_escape_string(htmlspecialchars(trim($_POST['site'])));
	$address			= mysql_real_escape_string(htmlspecialchars(trim($_POST['address'])));
	$report_channel		= mysql_real_escape_string(htmlspecialchars(trim($_POST['report_channel'])));
	$contact_person		= mysql_real_escape_string(htmlspecialchars(trim($_POST['contact_person'])));
	$contact_no			= mysql_real_escape_string(htmlspecialchars(trim($_POST['contact_no'])));
	$add_info			= mysql_real_escape_string(htmlspecialchars(trim($_POST['add_info'])));
	$title 				= mysql_real_escape_string(htmlspecialchars(trim($_POST['title'])));
	$description		= mysql_real_escape_string(htmlspecialchars(trim($_POST['description'])));
	$sn					= mysql_real_escape_string(htmlspecialchars(trim($_POST['sn'])));
	$asset				= mysql_real_escape_string(htmlspecialchars(trim($_POST['asset'])));
	$service_type		= mysql_real_escape_string(htmlspecialchars(trim($_POST['service_type'])));
	$category			= mysql_real_escape_string(htmlspecialchars(trim($_POST['category'])));
	// $product			= mysql_real_escape_string(htmlspecialchars(trim($_POST['product'])));
	$sla	 			= mysql_real_escape_string(htmlspecialchars(trim($_POST['sla'])));
	$severity 			= mysql_real_escape_string(htmlspecialchars(trim($_POST['severity'])));
	$recurrence 		= mysql_real_escape_string(htmlspecialchars(trim($_POST['recurrence'])));


/*--New Case ID------------------------------------------------------*/
	$getNewCaseID		=	"SELECT getCaseID('$project') caseID FROM DUAL";
	$result_newCaseID	=	mysql_query($getNewCaseID) or die("sql= ". $getNewCaseID);          
	$row_newCaseID		=	mysql_fetch_array( $result_newCaseID );
	$case_id		    =	$row_newCaseID['caseID'];
/*--New Case ID--------------------------------------------------*/


   $addCase  = "INSERT INTO CASEs (case_id,project_code, client_code,site_id,addr_id,caller,contact,info,via,servType,cat,item,asset,sn,title,problem,sts,sla,flag,recurrence,open_by,open_date) ". 
                 "VALUES('$case_id','".$project."','".$client."','".$site."','".$address."','".$contact_person."','".$contact_no."','".$add_info."','".$report_channel."','".$service_type."','".$category."','',UCASE('".$asset."'),UCASE('".$sn."'), ".
                 "'".$title."','".$description."','0','".$sla."','".$severity."','".$recurrence."','".$_SESSION['username']."',now())";
    mysql_query($addCase) or die($addCase .mysql_error());
    echo"SAVED";
}
?>