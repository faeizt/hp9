<?php 
	include '../DB.php';
	$con = mysql_connect($host,$user,$pass);
	$dbs = mysql_select_db($databaseName, $con);

	if(isset($_GET['project'])){
		$project = $_GET['project'];
		$sql = "select id as sla from sla where project_code='$project'";
		$query	=	mysql_query($sql)  or die("sql= ". $sql);        //query
		$result		=	mysql_fetch_array( $query );
		$sla   		=  $result['sla'];

		echo $sla;
	}

?>