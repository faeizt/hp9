<?php 
include '../DB.php';
  $selected	=   htmlspecialchars(trim($_GET['selected'])); 
  $result 	=  	mysql_query("SELECT *  FROM specialization");          //query
  $num  	= 	mysql_numrows($result);
  $i 		=	0;?>
  <option></option>
  <?
  while ($i < $num) {
    $id    =  mysql_result($result,$i,"id");
    $name 	 =  mysql_result($result,$i,"name");

    $i++;

    ?>
    <option value="<?=$id?>" <?if($id==$selected){echo"selected";}?>><?=$name?></option><?php 
  } 

?>