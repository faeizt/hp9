<?php 
include '../DB.php';
  $selected	=   htmlspecialchars(trim($_GET['selected'])); 
  $specialization_current = "";
  if ($selected!="") $result   =   mysql_query("SELECT user_id id,NAME FROM sys_users where specialization='$selected'");          //query
  else $result   =   mysql_query("SELECT id,NAME,specialization FROM v_user ");          //query
  $num  	= 	mysql_numrows($result);
  $i 		=	0;?>
  <option></option>
  <?
  while ($i < $num) {
    $id    =  mysql_result($result,$i,"id");
    $name 	 =  mysql_result($result,$i,"name");
    $specialization    =  mysql_result($result,$i,"specialization");

    $i++;
    if ($specialization != $specialization_current) {$specialization_current=$specialization;?>
      <optgroup label="<?=$specialization?>"  ><?
    }
    ?>
  
    <option value="<?=$id?>" <?if($id==$selected){echo"selected";}?>><?=$name?></option><?php 
          if ($client != $client_current) {?>
      </optgroup><?
    }
  } 

?>