

<?php 
include '../DB.php';
  $selected	=   htmlspecialchars(trim($_GET['selected'])); 
  $result 	=  	mysql_query("SELECT  CODE,code_name FROM code_definition WHERE code_cat = 'servicetyp'");          //query
  $num  	= 	mysql_numrows($result);
  $i 		=	0;?>
<option></option>
  <?
  while ($i < $num) {
    $id    =  mysql_result($result,$i,"CODE");
    $name 	 =  mysql_result($result,$i,"code_name");

    $i++;

    ?>
    <option value="<?=$id?>" <?if($id==$selected){echo"selected";}?>><?=$name?></option><?php 
  } 

?>