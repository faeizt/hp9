<?php 
include '../DB.php';
  $selected	=   htmlspecialchars(trim($_GET['selected'])); 
  $client =   htmlspecialchars(trim($_GET['client'])); 

  if($client=="" || $client=="null") $result   =   mysql_query("SELECT *  FROM project");          //query
  else $result   =   mysql_query("SELECT *  FROM project where client_code = '$client'");
  $num  	= 	mysql_numrows($result);
  $i 		=	0;
  if($num>1){?>
  <option></option>
  <?
  }
  while ($i < $num) {
    $id    =  mysql_result($result,$i,"project_code");
    $name 	 =  mysql_result($result,$i,"project_name");

    $i++;

    ?>
    <option value="<?=$id?>" <?if($id==$selected){echo"selected";}?>><?=$name?></option><?php 
  } 

?>