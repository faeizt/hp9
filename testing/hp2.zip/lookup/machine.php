

<?php 
include '../DB.php';
  $selected	=   htmlspecialchars(trim($_GET['selected'])); 
  $result 	=  	mysql_query("SELECT product_id, CONCAT(`product_type`,' ',`brand`,' ', `model`) machine_type FROM product WHERE project_code = '$selected'");          //query
  $num  	= 	mysql_numrows($result);
  $i 		=	0;  
  if($num>1){?>
  <option></option>
  <?
  }
  while ($i < $num) {
    $id    =  mysql_result($result,$i,"product_id");
    $name 	 =  mysql_result($result,$i,"machine_type");

    $i++;

    ?>
    <option value="<?=$id?>" <?if($id==$selected){echo"selected";}?>><?=$name?></option><?php 
  } 

?>