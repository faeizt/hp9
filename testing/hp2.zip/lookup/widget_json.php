<?
include '../DB.php';
$begin	    		= mysql_real_escape_string(htmlspecialchars(trim($_GET['begin'])));
$end	    		= mysql_real_escape_string(htmlspecialchars(trim($_GET['end'])));

$h = array();
$v = array();
$someWords = "open_date,onsite_time,pending_time,resolve_time";
$wordChunks = explode(",", $someWords);
for($j = 0; $j < count($wordChunks); $j++){

$open = "SELECT COUNT(*) open FROM cases WHERE ($wordChunks[$j] BETWEEN '$begin' AND DATE_ADD(STR_TO_DATE('$end', '%Y-%m-%d'), INTERVAL 2 DAY));";
$q = mysql_query($open);
$r = mysql_fetch_array($q) ;
array_push($v,array($wordChunks[$j]=>$r['open']));
}

print_r( json_encode($v) );

?>