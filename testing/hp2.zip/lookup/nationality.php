<?php 
include '../DB.php';
  $selected	=   htmlspecialchars(trim($_GET['selected'])); 

  $result =  mysql_query("SELECT *  FROM countries");          //query
  $num  = mysql_numrows($result);

  $i=0;?><option></option><?
  while ($i < $num) {
    $name    =  mysql_result($result,$i,"name");
    $id 	 =  mysql_result($result,$i,"id");
    $i++;

    ?>
    <option value="<?=$id?>" <?if($id==$selected){echo"selected";}?>><?=$name?></option><?php 
  } 

?>