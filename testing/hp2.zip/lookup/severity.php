

<?php 
include '../DB.php';
  $selected	=   htmlspecialchars(trim($_GET['selected'])); 
  $sla            = htmlspecialchars(trim($_GET['sla']));
  $result 	=  	mysql_query("SELECT severitylevel , code_name FROM severity LEFT JOIN code_definition ON severitylevel=CODE AND code_cat = 'flag' WHERE sla = '$sla' ");          //query
  $num  	= 	mysql_numrows($result);
  $i 		=	0;?>
<option></option>
  <?
  while ($i < $num) {
    $id    =  mysql_result($result,$i,"severitylevel");
    $name 	 =  mysql_result($result,$i,"code_name");

    $i++;

    ?>
    <option value="<?=$id?>" <?if($id==$selected){echo"selected";}?>><?=$name?></option><?php 
  } 

?>