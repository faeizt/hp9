<?php 
include '../DB.php';
  $selected =   htmlspecialchars(trim($_GET['selected'])); 
  $client_current = "";
  $result   =   mysql_query("SELECT *  FROM v_project order by client_code");          //query
  $num  	= 	mysql_numrows($result);
  $i 		=	0;
  if($num>1){?>
  <option></option>
  <?
  }
  while ($i < $num) {
    $id    =  mysql_result($result,$i,"project_code");
    $project_name 	 =  mysql_result($result,$i,"project_name");
    $client    =  mysql_result($result,$i,"client_code");
    $name    =  mysql_result($result,$i,"name");

    $i++;
    if ($client != $client_current) {$client_current=$client;?>
      <optgroup label="<?=$client?>" data-subtext="<?=$name?>" ><?
    }
    ?>
    <option value="<?=$id?>" <?if($id==$selected){echo"selected";}?>><?=$project_name?></option><?php 
        if ($client != $client_current) {?>
      </optgroup><?
    }
    } 

?>