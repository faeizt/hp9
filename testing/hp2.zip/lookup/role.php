<?php 
include '../DB.php';
  $selected	=   htmlspecialchars(trim($_GET['selected'])); 
  $result 	=  	mysql_query("SELECT *  FROM role");          //query
  $num  	= 	mysql_numrows($result);
  $i 		=	0;?><option></option><?
  while ($i < $num) {
    $name    =  mysql_result($result,$i,"type");
    $id 	 =  mysql_result($result,$i,"role_id");

    $i++;

    ?>
    <option value="<?=$id?>" <?if($id==$selected){echo"selected";}?>><?=$name?></option><?php 
  } 

?>